package Student;

public class AreaPeriTriangle {

	public static void main(String[] args) {
		
		Triangle ob = new Triangle();
		int side1 = 3, side2 = 4, side3 = 5;
		
		
		ob.Triangle(side1, side2, side3);
		
		

	}
	
}
