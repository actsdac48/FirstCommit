package AreaRectangle;

public class Area {

	public void Area() {
		
	}
	
	
	public int Area(int side1, int side2) {
		return side1*side2;
		
	}

}
