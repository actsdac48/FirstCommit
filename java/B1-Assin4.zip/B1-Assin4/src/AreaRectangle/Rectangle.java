package AreaRectangle;

public class Rectangle {

	public static void main(String[] args) {
		int side1 = 4;
		int side2 = 5;
		int side3 = 5;
		int side4 = 8;
		
		Area ob = new Area();
		System.out.println("Area of first Rectangle : " + ob.Area(side1, side2));
		
		System.out.println("Area of first Rectangle : " + ob.Area(side3, side4));
		
		
		

	}

}
