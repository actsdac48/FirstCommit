package Inheritance;

public class Child extends Parent{

	public void printMessageChild() {
		System.out.println("This is Child Classs");
	}

}
