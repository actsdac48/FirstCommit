package Inheritance;

public class Parent {

	public void printMessageParent() {
		System.out.println("This is Parent Calss");
	}

}
