package RectangleQue;

class Square extends Rectangle {
	
	public Square() {
		// TODO Auto-generated constructor stub
	}
    
    Square(int side) {
        super(side, side);
    }
}
