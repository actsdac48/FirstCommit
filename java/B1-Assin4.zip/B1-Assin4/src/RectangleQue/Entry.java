package RectangleQue;

public class Entry {

	public static void main(String[] args) {
		
		//For Rectangle
		System.out.println("For Rectangle : ");
		Rectangle rOb = new Rectangle();
		rOb.displayArea();
		rOb.displayPerimeter();
		
		//For Square
		System.out.println("For Square : ");
		Square sOb = new Square();
		sOb.displayArea();
		sOb.displayPerimeter();

	}

}
