package Date;

public class Date {
	private int day = 1;
	private int month = 1;
	private int year = 2025;
	
	public Date() {};
	
	public Date(int day, int month, int year) {
		setDate(day,month,year);
	}
	
	public void setDate(int day, int month, int year) {
		if(year > 2500 || year < 1900)
			this.year = 2025;
		else
			this.year = year;
		
		
		if (month > 12) {
			int add = month%12;
			this.month = add;
			this.year = year+1;
		}
		else 
			this.month = month;
		
		
		
		if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
			if(day > 31) {
				int add = day%31;
				this.day = add;
				this.month = month+1;
			}
			else
				this.day = day;
		}
		
		
		
		else if(month == 4 || month == 6 || month == 9 || month == 11) {
			if(day > 30) {
				int add = day%30;
				this.day = add;
				this.month = month+1;
		}
		else
			this.day = day;
		}
		
		else if(month == 2) {
			if(year%4 == 0 || year%400 == 0) {
				if(day > 28) {
					int add = day%28;
					this.day = add;
					this.month = month+1;
				}
				else
					this.day = day;
			}
			else {
				if(day > 27) {
					int add = day%27;
					this.day = add;
					this.month = month+1;
				}
				else
					this.day = day;
			}
				
		}
		
		 
		
	}
	
	
	public int getDay() {
		return day;
	}
	
	public int getMonth() {
		return month;
	}
	
	public int getYear() {
		return year;
	}

	public void setDay(int addDays) {
		if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
			if(addDays > 31) {
				int add = addDays%31;
				this.day = add;
				this.month = month+1;
			}
			else
				this.day = addDays;
		}
		
		
		
		else if(month == 4 || month == 6 || month == 9 || month == 11) {
			if(addDays > 30) {
				int add = addDays%30;
				this.day = add;
				this.month = month+1;
		}
		else
			this.day = addDays;
		}
		
		else if(month == 2) {
			if(year%4 == 0 || year%400 == 0) {
				if(addDays > 28) {
					int add = addDays%28;
					this.day = add;
					this.month = month+1;
				}
				else
					this.day = addDays;
			}
			else {
				if(addDays > 27) {
					int add = addDays%27;
					this.day = add;
					this.month = month+1;
				}
				else
					this.day = addDays;
			}
		}
	}

	public void setMonth(int month) {
		if (month > 12) {
			int add = month%12;
			this.month = add;
			this.year = year+1;
		}
		else 
			this.month = month;
	}

	public void setYear(int year) {
		if(year > 2500 || year < 1900)
			this.year = 2025;
		else
			this.year = year;
	}
	
	
	
}
