package ShapeQue;

public class Shape {

	
	
	
	
	public void displayShape() {
		System.out.println("This is shape");
	}

}
