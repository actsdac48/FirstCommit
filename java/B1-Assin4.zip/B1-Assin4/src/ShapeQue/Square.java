package ShapeQue;

public class Square extends Rectangle{

	public Square() {
		// TODO Auto-generated constructor stub
	}

	
	
	public void display() {
		System.out.println("Square is a rectangle");
	}
	

}
