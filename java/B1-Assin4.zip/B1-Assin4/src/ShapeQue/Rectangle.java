package ShapeQue;

public class Rectangle extends Shape{

	public Rectangle() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	
	
	public void displayRectangle() {
		System.out.println("This is rectangular shape");
	}

}
