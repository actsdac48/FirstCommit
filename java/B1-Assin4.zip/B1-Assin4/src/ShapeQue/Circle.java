package ShapeQue;

public class Circle extends Shape{

	public Circle() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	
	public void display() {
		System.out.println("This is circular shape");
	}

}
