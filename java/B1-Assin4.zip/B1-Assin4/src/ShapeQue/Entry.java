package ShapeQue;

public class Entry {

	

	public static void main(String[] args) {
		
		Square sOb = new Square();
		sOb.displayShape();
		
		sOb.displayRectangle();
		
		
		
		
		   
        

	}

}
