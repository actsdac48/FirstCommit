package classcode;

public class Decrement implements Runnable {

	
	
	Data objData;
	
	public Decrement(Data objData) {
		super();
		this.objData = objData;
	}
	
	
	@Override
	public void run() {

		while(true) {
			try {
				synchronized(objData) {
					System.out.println("Run in Decrement----------" + --objData.value);
					Thread.sleep(100);
				}
			
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
	

}
