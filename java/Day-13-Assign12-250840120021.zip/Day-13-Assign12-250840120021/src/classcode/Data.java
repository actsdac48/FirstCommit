package classcode;

public class Data {
	int value;
}
