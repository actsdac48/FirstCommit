package generateotp;


import java.util.LinkedList;


public class Entry {

	public static void main(String[] args) throws InterruptedException {
		
		LinkedList<Object> linkedList = new LinkedList<>();
		
		
		Runnable GeneratorThread = () ->
		{
			String sum = "";
			int idx = 3;
			while(idx > 0) {
				sum += (int)(Math.random() * 9);
				idx--;
			}
			
			linkedList.add(sum);
		};
		
		
		for(int i = 0; i < 5; i++) {
			Thread obj = new Thread(GeneratorThread);
			obj.start();
			try {
				synchronized(GeneratorThread) {
					
					
					
					Thread.sleep(15);
				}
				
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			System.out.println("OTP added is : " + linkedList.getLast());
		}
		
		
		
		Runnable ConsumerThread  = () -> linkedList.removeLast();
		
		try {
			for(int i = 0; i < 4; i++) {
				Thread obj1 = new Thread(ConsumerThread);
				obj1.start();
				synchronized(ConsumerThread) {
					
					Thread.sleep(10);
					System.out.println("OTP removed is : " + linkedList.getLast());
				}
			}
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
	
		
		
		
		
		
//		for(int i = 0; i < 5; i++) {
//			linkedList.add(GeneratorThread.get());
//			System.out.print(linkedList.get(i) + "\t");
//		}
//		
		
//		System.out.println(linkedList);
//		linkedList.remove();
//		System.out.println(linkedList);
		
//		Thread writeThread = new Thread(GeneratorThread);
//		writeThread.start();
		
//		Runnable ReaderThread = () ->
//		{
//			
//		};
//		Thread readerThread = new Thread(ReaderThread);
//		readerThread.start();

	}

}
