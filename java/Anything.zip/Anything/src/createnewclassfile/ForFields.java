package createnewclassfile;

public class ForFields {

	public ForFields() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
