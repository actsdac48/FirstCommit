import EmployeeInheritance.Employee;
import EmployeeInheritance.Engineer;
import EmployeeInheritance.Manager;
import EmployeeInheritance.SalesPerson;

public class Entry {

	public static void main(String[] args) {
		
		String name = null;
		
		String address = null;
		
		int age = 0;
		
		boolean gender = true;
		
		long basicSalary = 0;
		
		
		Employee [] objEmployee = new Employee[100];
		int count = 0;
		
		
		
		
		int choice, ch;
		do {
			
			System.out.println("1. Add Employee\n2. Display All\n3. Sort By\n4. Save\n5. Load\n6. Exit\nEnter Your Choice.............");
			choice = GetInput.getInt();
			
			switch(choice) {
				case 1 : {
					do {
						System.out.println("Enter which type of Employee you want to add : \n1. Manager\n2. Engineer\n3. SalesPerson\n4. Main Menu");
						ch = GetInput.getInt();
						
						switch(ch) {
							//For Manager
							case 1 : {
								
								inputData();		
								System.out.print("Enter HRA : ");
								long hRa = GetInput.getInt();	
								
								
								objEmployee[count++] = new Manager(name, address, age, gender, basicSalary,hRa);
								System.out.println("Total Employees : " + count);
								
							} break;
							
							//For Engineer
							case 2 : {
								
								inputData();
								System.out.print("Enter Overtime : ");
								long overtime = GetInput.getInt();	
								
								
								objEmployee[count++] = new Engineer(name, address, age, gender, basicSalary,overtime);
								System.out.println("Total Employees : " + count);
							} break;
							
							//For SalesPerson
							case 3 : {
									
								inputData();
								System.out.print("Enter commision : ");
								long commision= GetInput.getInt();	
								
								
								objEmployee[count++] = new SalesPerson(name, address, age, gender, basicSalary,commision);
								System.out.println("Total Employees : " + count);
							} break;
							
							//Go to main menu
							case 4 : {} break;
						}
						
					}while(ch<4);
					} break;
				case 2 : {
					System.out.println("All employees are : ");
					
				} break;
				case 3 : {} break;
				case 4 : {} break;
				case 5 : {} break;
				case 6 : {} break;
			}
			
		}while(choice < 6);

		
		
			
		}
		
	public static void inputData () {
		System.out.print("Enter name : ");
		String name = GetInput.getString();
		
		System.out.print("Enter Address : ");
		String address = GetInput.getString();
										
		System.out.print("Enter Age : ");
		int age = GetInput.getInt();
		
		System.out.print("Enter Gender (1 for M, 0 for F): ");
		String gen = GetInput.getString();
		boolean gender = Boolean.parseBoolean(gen);
		
		System.out.print("Enter Basic Salary : ");
		long basicSalary = GetInput.getInt();
	}
	
}
