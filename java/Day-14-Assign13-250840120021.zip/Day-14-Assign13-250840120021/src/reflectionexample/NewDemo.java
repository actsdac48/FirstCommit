package reflectionexample;

public abstract class NewDemo {

	


		int data = 5;
		
		

	

		public static void NewDemo() {

			System.out.println("*******************************");

		}

		public static void NewDemo1() {


		}

}
