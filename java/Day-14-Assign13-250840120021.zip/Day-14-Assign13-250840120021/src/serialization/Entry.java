package serialization;

public class Entry {

	public static void main(String[] args) {
		
		Data objSource = new Data();
		objSource.setiProtected(10);
		objSource.setiPublic("CDAC");
		
		Data objTarget = new Data();
		objTarget.setiProtected(10);
		objTarget.setiPublic("CDAC");
		
		if(objSource.equals(objTarget))
			System.out.println("Both objects are same--");
		else
			System.out.println("Objects are different--");
	}

}
