package StringMani;

public class AllToUpper {

	public static void main(String[] args) {
		
		String string = "The Quick BroWn FoX!";
		
		System.out.println("Original stirng : " + string);
		
		System.out.println("New stirng : " + string.toUpperCase());

	}

}
