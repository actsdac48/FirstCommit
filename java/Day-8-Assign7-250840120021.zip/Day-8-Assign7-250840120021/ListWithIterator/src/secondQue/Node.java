package secondQue;

public class Node<T> {

	T Data;
	
	Node<T> previous;
	
	Node<T> next;
	
	
	public Node(T data) {
		super();
		this.Data = data;
	}
	
}
