package transaction;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;


public class Entry {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		ArrayList<Transaction> trnsCollecton = new ArrayList<Transaction>();

		int loop = 0;

		while(loop < 2) {

			System.out.println("Enter transaction number :");
			int txI = sc.nextInt();

			LocalDateTime d = LocalDateTime.now();

			System.out.println("Enter transaction Amount :");
			float txAmount = sc.nextInt();

			System.out.println("Enter transaction status (1 for true or 0 for false) :"); 
			int txStatus = sc.nextInt(); 
			boolean bool = true; 
			if(txStatus > 0) 
				bool = false; 
			System.out.println("Enter transaction Arrears status (1 for true or 0 for false) :"); 
			int txArrears = sc.nextInt(); 
			boolean boolArrears = true;
			if(txArrears > 0) 
				boolArrears = false;

			Transaction ob = new Transaction(txI, d, txAmount, bool, boolArrears);

			trnsCollecton.add(ob);

			loop++;
		}


		System.out.println("\n----- All Transactions -----");
		for(Transaction data : trnsCollecton)
		{
			System.out.println(data);
		}



		/*
		 * Predicate<Transaction> highVal = transaction -> transaction.txAmount > 5000;
		 * 
		 * List<Transaction> highValTx =
		 * trnsCollecton.stream().filter(highVal).collect(Collectors.toList());
		 * 
		 * System.out.println("\n----- All Transactions with txAmount > 5000 -----");
		 * for(Transaction data : highValTx) { System.out.println(data); }
		 * 
		 * 
		 * Predicate<Transaction> txStatusFalse = transaction -> transaction.txStatus ==
		 * false;
		 */

		//1. Getting all the Transactions from the Collection where the txAmount is > 5000

		System.out.println("\n------Getting all the Transactions from the Collection where the txAmount is > 5000-------");
		TransactionCheck<ArrayList<Transaction>, ArrayList<Transaction>> ob1 = (var) ->
		{
			ArrayList<Transaction> updatedList = new ArrayList<>();
			
			for(Transaction data : var) {
				if(data.txAmount > 5000) {
					updatedList.add(data);
				}
			}
			
			return updatedList;
		};
		System.out.println(ob1.check(trnsCollecton));
		
		
		
		//2. Getting all the Transactions where the txStatus is false
		System.out.println("\n--------Getting all the Transactions where the txStatus is false----------");
		TransactionCheck<ArrayList<Transaction>, ArrayList<Transaction>> ob2 = (var) ->
		{
			ArrayList<Transaction> updatedList = new ArrayList<>();
			
			for(Transaction data : var) {
				if(data.txStatus == false) {
					updatedList.add(data);
				}
			}
			
			return updatedList;
		};
		System.out.println(ob2.check(trnsCollecton));
			
		
		//Write a Lambda Function to generate the amount due. The amount due is 
		//calculated as the txAmount + Rs. 500/- + 18% of txAmount if the txArrears is true 
		//else if txArrears if false then only the txAmount will be returned
		
		System.out.println("\n--------Getting all the Transactions where the txArrears is true----------");
		TransactionCheck<ArrayList<Transaction>, ArrayList<Transaction>> ob3 = (var) ->
		{
			
			for(Transaction data : var) {
				if(data.txArrears) {
					data.txAmount = data.txAmount + 500 + ((18/data.txAmount) * 100);
				}
			}
			
			return var;
		};
		System.out.println(ob3.check(trnsCollecton));
		
	}

}
