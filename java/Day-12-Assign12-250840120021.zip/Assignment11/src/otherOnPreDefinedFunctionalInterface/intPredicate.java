package otherOnPreDefinedFunctionalInterface;

public interface intPredicate {
	boolean test(int value); 
}
